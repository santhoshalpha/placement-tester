const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/quizDB', { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// MongoDB Schema
const QuizResultSchema = new mongoose.Schema({
    score: {
        type: Number,
        required: true
    },
    totalQuestions: {
        type: Number,
        required: true
    }
});

const QuizResult = mongoose.model('QuizResult', QuizResultSchema);

// API Endpoint to store quiz results
app.post('/api/results', async (req, res) => {
    try {
        const { score, totalQuestions } = req.body;
        const result = new QuizResult({ score, totalQuestions });
        await result.save();
        res.status(201).json({ message: 'Quiz result stored successfully!' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
