// Define an array of objects representing questions


console.log(question);

const question = [
    {
      question: "Which of the following sentences is correct?",
      options: ["a) She is going to the store tomorrow.", "b) She are going to the store tomorrow.", "c) She am going to the store tomorrow.", "d) She going to the store tomorrow."],
      correctAnswer: "a) She is going to the store tomorrow."
    },
    {
      question: "Choose the correct usage of the past tense:",
      options: ["a) I have ate lunch already.", "b) I have eaten lunch already.", "c) I have eat lunch already.", "d) I have eating lunch already."],
      correctAnswer: "b) I have eaten lunch already."
    },
    {
      question: "Identify the sentence with correct subject-verb agreement:",
      options: ["a) The group of students is going on a field trip.", "b) The group of students are going on a field trip.", "c) The group of students am going on a field trip.", "d) The group of students was going on a field trip."],
      correctAnswer: "a) The group of students is going on a field trip."
    },
    {
      question: "Choose the correct form of the verb to complete the sentence:",
      options: ["a) go", "b) goes", "c) went", "d) going"],
      correctAnswer: "c) went"
    },
    {
      question: "Identify the sentence with correct punctuation:",
      options: ["a) She said 'hello' when she entered the room.", "b) She said 'hello'. When she entered the room.", "c) She said 'hello' when she entered the room.", "d) She said 'hello' when she entered the room"],
      correctAnswer: "a) She said 'hello' when she entered the room."
    }
  ];
  
  // Export the questions array for use in other modules
  export default question;
  