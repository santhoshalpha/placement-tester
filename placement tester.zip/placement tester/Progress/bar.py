import matplotlib.pyplot as plt

# Module results data
module_results = {
    'Module 1': 5,
    'Module 2': 3,
    'Module 3': 4
}

# Extract module names and scores
modules = list(module_results.keys())
scores = list(module_results.values())

# Create pie chart
plt.figure(figsize=(8, 8))  # Set the figure size
plt.pie(scores, labels=modules, autopct='%1.1f%%', colors=['lightblue', 'lightgreen', 'lightcoral'], startangle=90)

# Add title
plt.title('Module Results')

# Set the background color
plt.gca().set_facecolor('lightgrey')

# Show the chart
plt.show()
